---
title: Playbooks
permalink: /playbooks/

---

## Playbooks

Short SOPs and checklists for shipping safely.

<ul class="clean">
  <li><a href="/playbooks/display-qa-checklist/"><strong>QA checklist for display ads</strong></a><br><span class="badge">Playbook</span> What to check before trafficking (HTML5 + static).</li>
</ul>

