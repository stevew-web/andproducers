---
title: Stories
permalink: /stories/

---

## Stories

Operator lessons — anonymised, practical, and focused on what changed.

<ul class="clean">
  <li><a href="/stories/a-week-in-production/"><strong>A week in production: what really slows delivery</strong></a><br><span class="badge">Story</span> The common blockers and the SOP fixes that work.</li>
</ul>

